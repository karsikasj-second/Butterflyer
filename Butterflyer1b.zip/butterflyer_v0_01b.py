#!/usr/bin/env python3
"""
BUTTERFLYER v0.01
A rotating hypersigil / generative breakbeat instrument.

Dependencies:
    numpy
    pygame
    sounddevice

Controls:
    Mouse drag knob up/down      change value
    Mouse wheel over knob        fine change
    TAB / Shift+TAB              select knob
    Arrow Up/Right, Down/Left    change selected knob
    SPACE                        REBIRTH
    M                            MUTATE
    S                            SAVE last ~16 seconds to WAV
    ESC                          quit
"""

import math
import random
import threading
import time
import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pygame
import sounddevice as sd


# ----------------------------- constants ---------------------------------

SR = 48000
BLOCK = 1024
CHANNELS = 2
WIDTH, HEIGHT = 1120, 760
FPS = 60
CAPTURE_SECONDS = 24
SAVE_SECONDS = 16

BG = (8, 8, 12)
PANEL = (18, 18, 25)
TEXT = (232, 230, 220)
DIM = (122, 123, 132)
LINE = (70, 72, 84)
ACCENT = (229, 197, 101)

TAU = math.tau


# ----------------------------- utilities ---------------------------------

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def softclip(x):
    return np.tanh(x)


def equal_power_pan(pan):
    pan = clamp(pan, -1.0, 1.0)
    a = (pan + 1.0) * math.pi * 0.25
    return math.cos(a), math.sin(a)


def hsv_to_rgb(h, s, v):
    # h, s, v in [0,1]
    h = h % 1.0
    i = int(h * 6.0)
    f = h * 6.0 - i
    p = v * (1.0 - s)
    q = v * (1.0 - f * s)
    t = v * (1.0 - (1.0 - f) * s)
    i %= 6
    vals = (
        (v, t, p), (q, v, p), (p, v, t),
        (p, q, v), (t, p, v), (v, p, q)
    )[i]
    return tuple(int(clamp(c) * 255) for c in vals)


# ----------------------------- parameters --------------------------------

@dataclass
class Param:
    name: str
    value: float
    lo: float = 0.0
    hi: float = 1.0

    def set(self, v):
        self.value = clamp(v, self.lo, self.hi)

    def add(self, d):
        self.set(self.value + d)


# ----------------------------- voices ------------------------------------

class ActiveVoice:
    """A small synthesized percussion event rendered block-by-block."""
    def __init__(self, kind, velocity, pan, spectra, flutter):
        self.kind = kind
        self.velocity = velocity
        self.pan = pan
        self.spectra = spectra
        self.flutter = flutter
        self.age = 0

        if kind == "BODY":
            self.length = int(SR * (0.16 + 0.22 * random.random()))
            self.f0 = 78.0 + 75.0 * spectra + random.uniform(-7, 7)
            self.f1 = 34.0 + 18.0 * spectra + random.uniform(-2, 2)
            self.phase = random.random() * TAU
        elif kind == "DUST":
            self.length = int(SR * (0.08 + 0.23 * random.random()))
            self.ring = 145.0 + 175.0 * spectra + random.uniform(-30, 30)
            self.phase = random.random() * TAU
        else:  # METAL
            self.length = int(SR * (0.025 + 0.16 * random.random()))
            base = 1550.0 + 2600.0 * spectra
            self.freqs = np.array(
                [base, base * 1.27, base * 1.73, base * 2.41],
                dtype=np.float32
            )
            self.phases = np.random.random(4).astype(np.float32) * TAU

    def render(self, n):
        remain = self.length - self.age
        m = min(n, remain)
        if m <= 0:
            return np.zeros((n, 2), dtype=np.float32), True

        idx = self.age + np.arange(m, dtype=np.float32)
        t = idx / SR
        out = np.zeros(m, dtype=np.float32)

        if self.kind == "BODY":
            # Exponential pitch dive; short noisy beater; slight flutter FM.
            dur = self.length / SR
            frac = np.minimum(t / max(dur, 1e-6), 1.0)
            f = self.f1 + (self.f0 - self.f1) * np.exp(-8.5 * frac)
            flutter = 1.0 + (0.002 + 0.012 * self.flutter) * np.sin(
                TAU * (5.5 + 12 * self.flutter) * t
            )
            # Integrate frequency continuously across callback blocks.
            increments = TAU * f * flutter / SR
            ph = self.phase + np.cumsum(increments)
            if m:
                self.phase = float(ph[-1] % TAU)
            env = np.exp(-8.0 * frac)
            click = np.random.randn(m).astype(np.float32) * np.exp(-65.0 * t) * 0.09
            out = np.sin(ph).astype(np.float32) * env + click

        elif self.kind == "DUST":
            # Snare-ish dusty membrane: noise + a weak, unstable ring.
            dur = self.length / SR
            frac = np.minimum(t / max(dur, 1e-6), 1.0)
            env = np.exp(-(8.0 + 10.0 * self.spectra) * frac)
            noise = np.random.randn(m).astype(np.float32)
            # crude spectral tilt by differentiating a little when bright
            if self.spectra > 0.45 and m > 2:
                noise[1:] = noise[1:] - (0.25 + 0.45 * self.spectra) * noise[:-1]
            ring = np.sin(
                self.phase + TAU * self.ring * t
                + 0.8 * self.flutter * np.sin(TAU * 13.0 * t)
            ).astype(np.float32)
            out = env * (0.66 * noise + 0.34 * ring)

        else:  # METAL
            dur = self.length / SR
            frac = np.minimum(t / max(dur, 1e-6), 1.0)
            env = np.exp(-(12.0 + 15.0 * (1.0 - self.spectra)) * frac)
            bank = np.zeros(m, dtype=np.float32)
            for j, f in enumerate(self.freqs):
                wobble = 1.0 + 0.008 * self.flutter * np.sin(
                    TAU * (7.0 + j * 3.7) * t
                )
                bank += np.sin(self.phases[j] + TAU * f * wobble * t).astype(np.float32)
            out = (bank / len(self.freqs)) * env
            out += np.random.randn(m).astype(np.float32) * env * 0.11

        out *= self.velocity
        l, r = equal_power_pan(self.pan)
        stereo = np.zeros((n, 2), dtype=np.float32)
        stereo[:m, 0] = out * l
        stereo[:m, 1] = out * r

        self.age += m
        return stereo, self.age >= self.length


# ----------------------------- engine ------------------------------------

class ButterflyEngine:
    """
    Nine rotating agents. Their phase crossings produce percussion events.
    There is no traditional step sequencer.
    """
    def __init__(self):
        self.lock = threading.RLock()
        self.params = {
            "ROTATION": Param("ROTATION", 0.56),
            "DENSITY": Param("DENSITY", 0.47),
            "DRIFT": Param("DRIFT", 0.28),
            "GRAVITY": Param("GRAVITY", 0.62),
            "SYMMETRY": Param("SYMMETRY", 0.53),
            "MUTATION": Param("MUTATION", 0.16),
            "FLUTTER": Param("FLUTTER", 0.22),
            "SPECTRA": Param("SPECTRA", 0.48),
        }

        self.base_bpm = 132.0
        self.agent_count = 9
        self.ratios = np.array(
            [0.25, 1/3, 0.5, 2/3, 0.75, 1.0, 1.25, 1.5, 2.0],
            dtype=np.float64
        )
        self.phases = np.random.random(self.agent_count)
        self.bias = np.random.uniform(-1, 1, self.agent_count)
        self.kinds = ["BODY", "METAL", "DUST",
                      "BODY", "DUST", "METAL",
                      "DUST", "BODY", "METAL"]
        self.active = []
        self.sample_clock = 0
        self.global_angle = 0.0
        self.last_event_flash = np.zeros(self.agent_count, dtype=np.float32)

        self.capture = np.zeros((SR * CAPTURE_SECONDS, 2), dtype=np.float32)
        self.capture_pos = 0
        self.capture_filled = False

        self.stream = None
        self.running = False
        self.last_saved = None

        # diagnostics / metering
        self.event_count = 0
        self.callback_count = 0
        self.peak_meter = 0.0
        self.callback_error = ""
        self.start_time = time.time()

    def start(self):
        self.stream = sd.OutputStream(
            samplerate=SR,
            blocksize=BLOCK,
            channels=CHANNELS,
            dtype="float32",
            callback=self.audio_callback,
            latency="high",
            prime_output_buffers_using_stream_callback=True,
        )
        self.stream.start()
        self.running = True
        try:
            print("BUTTERFLYER AUDIO DEVICE:", self.stream.device)
            print("BUTTERFLYER AUDIO LATENCY:", self.stream.latency)
            print("BUTTERFLYER BLOCK SIZE:", BLOCK)
        except Exception:
            pass

        # Immediate audible proof-of-life.  These are queued into the same
        # synthesis path used by the hypersigil, so if these sound, the DSP
        # path and output callback are alive.
        with self.lock:
            self.active.append(ActiveVoice("BODY", 0.95, -0.15, 0.42, 0.18))
            self.active.append(ActiveVoice("METAL", 0.55, 0.18, 0.58, 0.22))

    def stop(self):
        self.running = False
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None

    def rotation_multiplier(self):
        v = self.params["ROTATION"].value
        return 0.52 + 1.65 * v

    def effective_bpm(self):
        return self.base_bpm * self.rotation_multiplier()

    def _event_probability(self, i):
        p = self.params
        density = p["DENSITY"].value
        gravity = p["GRAVITY"].value
        symmetry = p["SYMMETRY"].value

        # agents nearer the "cardinal" roles become more stable under gravity
        role = i / max(1, self.agent_count - 1)
        anchor = 1.0 - abs(0.5 - ((role * 4.0) % 1.0)) * 2.0
        base = 0.08 + density * 0.77
        grav_bonus = gravity * 0.18 * anchor

        # opposite triangles increasingly echo one another at high symmetry
        mirror = 1.0 - abs(i - (self.agent_count - 1 - i)) / self.agent_count
        sym_bonus = symmetry * 0.10 * mirror
        return clamp(base + grav_bonus + sym_bonus, 0.02, 0.98)

    def trigger(self, i, phase_fraction=0.0):
        p = self.params
        if random.random() > self._event_probability(i):
            return

        kind = self.kinds[i]
        velocity = 0.30 + 0.55 * random.random()

        gravity = p["GRAVITY"].value
        # BODY anchors are stronger when gravity is high.
        if kind == "BODY":
            velocity *= 0.80 + 0.45 * gravity

        symmetry = p["SYMMETRY"].value
        side = -1.0 + 2.0 * (i / max(1, self.agent_count - 1))
        pan = side * (1.0 - 0.72 * symmetry)
        pan += random.uniform(-0.12, 0.12) * (1.0 - symmetry)
        pan = clamp(pan, -1.0, 1.0)

        spectra = p["SPECTRA"].value
        flutter = p["FLUTTER"].value
        self.active.append(ActiveVoice(kind, velocity, pan, spectra, flutter))
        self.last_event_flash[i] = 1.0
        self.event_count += 1

        # "butterfly echo": sparse asymmetric secondary hit
        if random.random() < 0.05 + 0.16 * flutter:
            echo_kind = "METAL" if kind == "DUST" else "DUST"
            self.active.append(
                ActiveVoice(
                    echo_kind,
                    velocity * random.uniform(0.18, 0.42),
                    -pan * (0.5 + 0.5 * symmetry),
                    clamp(spectra + random.uniform(-0.15, 0.15)),
                    flutter,
                )
            )

    def audio_callback(self, outdata, frames, time_info, status):
        try:
            self._audio_callback_impl(outdata, frames, time_info, status)
        except Exception as exc:
            # Never let PortAudio fail invisibly.  Output silence and expose
            # the exception to the GUI / terminal.
            outdata.fill(0)
            self.callback_error = f"{type(exc).__name__}: {exc}"
            print("BUTTERFLYER AUDIO CALLBACK ERROR:", self.callback_error)

    def _audio_callback_impl(self, outdata, frames, time_info, status):
        self.callback_count += 1
        if status:
            # Keep the latest PortAudio status visible without flooding stdout.
            self.callback_error = f"PortAudio status: {status}"

        with self.lock:
            p = self.params
            drift = p["DRIFT"].value
            mut = p["MUTATION"].value

            rot = self.rotation_multiplier()
            cycles_per_sec = (self.base_bpm / 60.0) / 4.0
            block_seconds = frames / SR

            old = self.phases.copy()
            jitter = self.bias * drift * 0.045
            speeds = self.ratios * (1.0 + jitter)
            advance = cycles_per_sec * rot * speeds * block_seconds
            self.phases = (self.phases + advance) % 1.0

            # Trigger when an agent wraps through phase zero.
            wrapped = self.phases < old
            for i in np.flatnonzero(wrapped):
                self.trigger(int(i))

            # Slow state mutation: restrained, not constant dice throwing.
            if random.random() < mut * block_seconds * 0.75:
                j = random.randrange(self.agent_count)
                self.bias[j] = clamp(self.bias[j] + random.uniform(-0.12, 0.12), -1, 1)

            mix = np.zeros((frames, 2), dtype=np.float32)
            survivors = []
            for voice in self.active:
                block, done = voice.render(frames)
                mix += block
                if not done:
                    survivors.append(voice)
            self.active = survivors

            # Tiny living bus movement.
            flutter = p["FLUTTER"].value
            t0 = self.sample_clock / SR
            t = t0 + np.arange(frames, dtype=np.float32) / SR
            bus = 0.91 + (0.012 + 0.022 * flutter) * np.sin(
                TAU * (0.13 + 0.41 * flutter) * t
            )
            mix *= bus[:, None]

            # Preserve punch but keep runaway overlaps safe.
            mix = softclip(mix * 1.18).astype(np.float32)
            outdata[:] = mix

            # GUI meter: fast attack, slow decay.
            peak = float(np.max(np.abs(mix))) if mix.size else 0.0
            self.peak_meter = max(peak, self.peak_meter * 0.94)

            # rolling capture
            n = frames
            capn = len(self.capture)
            if self.capture_pos + n <= capn:
                self.capture[self.capture_pos:self.capture_pos+n] = mix
                self.capture_pos += n
                if self.capture_pos == capn:
                    self.capture_pos = 0
                    self.capture_filled = True
            else:
                first = capn - self.capture_pos
                self.capture[self.capture_pos:] = mix[:first]
                rest = n - first
                self.capture[:rest] = mix[first:]
                self.capture_pos = rest
                self.capture_filled = True

            self.sample_clock += frames
            self.global_angle = (self.global_angle + rot * block_seconds * 0.34) % TAU
            self.last_event_flash *= 0.91

    def mutate(self, strength=1.0):
        with self.lock:
            amount = 0.055 * strength
            protected = {"ROTATION"}
            for name, param in self.params.items():
                if name in protected:
                    continue
                if random.random() < 0.62:
                    param.add(random.uniform(-amount, amount))
            for i in range(self.agent_count):
                if random.random() < 0.40:
                    self.bias[i] = clamp(
                        self.bias[i] + random.uniform(-0.16, 0.16) * strength,
                        -1.0, 1.0
                    )

    def rebirth(self):
        with self.lock:
            self.phases = np.random.random(self.agent_count)
            self.bias = np.random.uniform(-0.75, 0.75, self.agent_count)
            self.active.clear()
            # retain the broad identity, but move to another organism
            for name in ("DENSITY", "DRIFT", "GRAVITY", "SYMMETRY",
                         "MUTATION", "FLUTTER", "SPECTRA"):
                self.params[name].set(
                    clamp(self.params[name].value + random.uniform(-0.18, 0.18))
                )

    def save_capture(self):
        with self.lock:
            available = len(self.capture) if self.capture_filled else self.capture_pos
            count = min(available, SR * SAVE_SECONDS)
            if count <= 0:
                return None

            end = self.capture_pos
            start = (end - count) % len(self.capture)
            if start < end:
                audio = self.capture[start:end].copy()
            else:
                audio = np.concatenate(
                    (self.capture[start:], self.capture[:end]), axis=0
                )

        stamp = time.strftime("%Y%m%d_%H%M%S")
        path = Path.cwd() / f"butterflyer_{stamp}.wav"
        pcm = np.clip(audio, -1.0, 1.0)
        pcm = (pcm * 32767.0).astype(np.int16)

        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(SR)
            wf.writeframes(pcm.tobytes())

        self.last_saved = str(path)
        return path


# ----------------------------- GUI ---------------------------------------

class Knob:
    def __init__(self, x, y, radius, param, key_hint=""):
        self.x = x
        self.y = y
        self.r = radius
        self.param = param
        self.key_hint = key_hint
        self.dragging = False
        self.drag_y = 0
        self.drag_value = 0

    def hit(self, pos):
        dx = pos[0] - self.x
        dy = pos[1] - self.y
        return dx*dx + dy*dy <= (self.r + 8) ** 2

    def begin_drag(self, y):
        self.dragging = True
        self.drag_y = y
        self.drag_value = self.param.value

    def drag(self, y):
        delta = (self.drag_y - y) / 180.0
        self.param.set(self.drag_value + delta)

    def end_drag(self):
        self.dragging = False

    def wheel(self, dy):
        self.param.add(0.018 * dy)

    def draw(self, screen, font, small, selected=False):
        pygame.draw.circle(screen, (31, 31, 40), (self.x, self.y), self.r)
        pygame.draw.circle(
            screen,
            ACCENT if selected else (92, 93, 105),
            (self.x, self.y),
            self.r,
            2
        )
        a0 = math.radians(135)
        span = math.radians(270)
        a = a0 + span * self.param.value
        ex = self.x + math.cos(a) * self.r * 0.72
        ey = self.y + math.sin(a) * self.r * 0.72
        pygame.draw.line(screen, TEXT, (self.x, self.y), (ex, ey), 3)

        label = font.render(self.param.name, True, TEXT)
        screen.blit(label, label.get_rect(center=(self.x, self.y + self.r + 23)))

        val = small.render(f"{self.param.value:0.2f}", True, DIM)
        screen.blit(val, val.get_rect(center=(self.x, self.y + self.r + 43)))


class ButterflyGUI:
    def __init__(self, engine):
        pygame.init()
        pygame.display.set_caption("BUTTERFLYER v0.01b — AUDIO SAFE")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        self.engine = engine
        self.font = pygame.font.Font(None, 24)
        self.small = pygame.font.Font(None, 19)
        self.big = pygame.font.Font(None, 42)
        self.titlefont = pygame.font.Font(None, 58)

        names = list(engine.params.keys())
        self.knobs = []
        # four top, four bottom
        xs = [145, 385, 735, 975]
        ys = [135, 625]
        for row in range(2):
            for col in range(4):
                idx = row * 4 + col
                self.knobs.append(
                    Knob(xs[col], ys[row], 42, engine.params[names[idx]])
                )

        self.selected = 0
        self.message = "SPACE rebirth   M mutate   S save   TAB select"
        self.message_until = 0

    def show_message(self, text, seconds=2.7):
        self.message = text
        self.message_until = time.time() + seconds

    def draw_yantra(self, cx, cy, radius):
        p = self.engine.params
        spectra = p["SPECTRA"].value
        symmetry = p["SYMMETRY"].value
        drift = p["DRIFT"].value

        # spectral colour is sonically meaningful and visually mirrored.
        hue = (0.075 + 0.68 * spectra + self.engine.global_angle / TAU * 0.12) % 1.0
        col = hsv_to_rgb(hue, 0.62, 0.93)
        dimcol = hsv_to_rgb((hue + 0.08) % 1.0, 0.38, 0.42)

        # outer circles / temporal field
        pygame.draw.circle(self.screen, dimcol, (cx, cy), int(radius), 1)
        pygame.draw.circle(self.screen, dimcol, (cx, cy), int(radius * 0.73), 1)
        pygame.draw.circle(self.screen, dimcol, (cx, cy), int(radius * 0.46), 1)

        # nine triangles; each is one event-producing time agent.
        for i in range(self.engine.agent_count):
            phase = self.engine.phases[i]
            flash = float(self.engine.last_event_flash[i])
            rr = radius * (0.34 + 0.055 * i)
            rr *= 0.97 + 0.05 * math.sin(TAU * phase)

            direction = -1 if i < 4 else 1
            base = (
                self.engine.global_angle * direction
                + TAU * phase
                + i * 0.19
                + self.engine.bias[i] * drift * 0.22
            )

            # alternating upward / downward triangles
            offset = 0 if (i % 2 == 0) else math.pi
            pts = []
            for k in range(3):
                ang = base + offset + k * TAU / 3.0 - math.pi / 2
                x = cx + math.cos(ang) * rr
                y = cy + math.sin(ang) * rr
                pts.append((int(x), int(y)))

            brightness = clamp(0.46 + flash * 0.54)
            tri_col = hsv_to_rgb(
                (hue + i * 0.028) % 1.0,
                clamp(0.45 + 0.25 * (1.0 - symmetry)),
                brightness
            )
            pygame.draw.polygon(self.screen, tri_col, pts, 1 + int(flash * 2))

        # bindu
        br = 4 + int(6 * p["GRAVITY"].value)
        pygame.draw.circle(self.screen, col, (cx, cy), br)

        # little rotating event nodes around the field
        for i in range(self.engine.agent_count):
            a = TAU * self.engine.phases[i] + self.engine.global_angle
            rr = radius * 1.05
            x = cx + math.cos(a) * rr
            y = cy + math.sin(a) * rr
            r = 2 + int(self.engine.last_event_flash[i] * 5)
            pygame.draw.circle(self.screen, col, (int(x), int(y)), r)

    def design_pos(self, pos):
        """Map current window coordinates into the fixed 1120x760 panel space."""
        w, h = self.screen.get_size()
        return (pos[0] * WIDTH / max(1, w), pos[1] * HEIGHT / max(1, h))

    def handle_event(self, e):
        if e.type == pygame.QUIT:
            return False

        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                return False
            elif e.key == pygame.K_SPACE:
                self.engine.rebirth()
                self.show_message("REBIRTH — geometry reseeded")
            elif e.key == pygame.K_m:
                self.engine.mutate(1.0)
                self.show_message("MUTATE — restrained genomic shift")
            elif e.key == pygame.K_t:
                # Manual proof-of-life trigger.
                with self.engine.lock:
                    self.engine.active.append(
                        ActiveVoice("BODY", 1.0, -0.15,
                                    self.engine.params["SPECTRA"].value,
                                    self.engine.params["FLUTTER"].value)
                    )
                    self.engine.active.append(
                        ActiveVoice("DUST", 0.75, 0.18,
                                    self.engine.params["SPECTRA"].value,
                                    self.engine.params["FLUTTER"].value)
                    )
                print("BUTTERFLYER: T received — forcing BODY + DUST test hit")
                self.show_message("TEST HIT — BODY + DUST")
            elif e.key == pygame.K_s:
                path = self.engine.save_capture()
                if path:
                    self.show_message(f"SAVED {path.name}", 4.0)
                else:
                    self.show_message("Nothing captured yet")
            elif e.key == pygame.K_TAB:
                backwards = bool(e.mod & pygame.KMOD_SHIFT)
                self.selected = (
                    self.selected + (-1 if backwards else 1)
                ) % len(self.knobs)
            elif e.key in (pygame.K_UP, pygame.K_RIGHT):
                self.knobs[self.selected].param.add(0.02)
            elif e.key in (pygame.K_DOWN, pygame.K_LEFT):
                self.knobs[self.selected].param.add(-0.02)

        elif e.type == pygame.MOUSEBUTTONDOWN:
            if e.button == 1:
                dpos = self.design_pos(e.pos)
                for idx, knob in enumerate(self.knobs):
                    if knob.hit(dpos):
                        self.selected = idx
                        knob.begin_drag(dpos[1])
                        break
            elif e.button in (4, 5):  # older pygame wheel events
                dy = 1 if e.button == 4 else -1
                dpos = self.design_pos(e.pos)
                for idx, knob in enumerate(self.knobs):
                    if knob.hit(dpos):
                        self.selected = idx
                        knob.wheel(dy)
                        break

        elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
            for knob in self.knobs:
                knob.end_drag()

        elif e.type == pygame.MOUSEMOTION:
            dpos = self.design_pos(e.pos)
            for knob in self.knobs:
                if knob.dragging:
                    knob.drag(dpos[1])

        elif e.type == pygame.MOUSEWHEEL:
            pos = self.design_pos(pygame.mouse.get_pos())
            for idx, knob in enumerate(self.knobs):
                if knob.hit(pos):
                    self.selected = idx
                    knob.wheel(e.y)
                    break

        return True

    def draw(self):
        self.screen.fill(BG)
        w, h = self.screen.get_size()

        # title
        title = self.titlefont.render("BUTTERFLYER", True, TEXT)
        self.screen.blit(title, (36, 25))
        sub = self.small.render(
            "rotating hypersigil / temporal percussion organism  v0.01",
            True, DIM
        )
        self.screen.blit(sub, (40, 76))

        # central panel
        panel = pygame.Rect(w//2 - 255, h//2 - 235, 510, 470)
        pygame.draw.rect(self.screen, PANEL, panel, border_radius=14)
        pygame.draw.rect(self.screen, LINE, panel, 1, border_radius=14)

        cx, cy = w // 2, h // 2 - 8
        self.draw_yantra(cx, cy, min(190, h * 0.28))

        bpm = self.engine.effective_bpm()
        meter = min(1.0, self.engine.peak_meter)
        stream_state = "OPEN" if (
            self.engine.stream is not None and self.engine.stream.active
        ) else "CLOSED"
        status_text = (
            f"audio {stream_state}   cb {self.engine.callback_count:07d}   "
            f"peak {meter:0.3f}   events {self.engine.event_count:05d}   "
            f"voices {len(self.engine.active):02d}"
        )
        status = self.small.render(status_text, True, DIM)
        self.screen.blit(status, status.get_rect(center=(cx, panel.bottom - 24)))

        # knobs keep a stable tabletop layout at the default size.
        # On resize, remap their x positions proportionally.
        sx = w / WIDTH
        sy = h / HEIGHT
        for idx, knob in enumerate(self.knobs):
            ox, oy = knob.x, knob.y
            knob.x = int(ox * sx)
            knob.y = int(oy * sy)
            knob.draw(self.screen, self.font, self.small, idx == self.selected)
            knob.x, knob.y = ox, oy

        # callback errors are shown prominently.
        if self.engine.callback_error:
            err = self.small.render(
                "AUDIO: " + self.engine.callback_error, True, (255, 120, 120)
            )
            self.screen.blit(err, err.get_rect(center=(w // 2, h - 48)))

        # helper / state line
        if time.time() > self.message_until:
            msg = "drag/scroll knobs   T test hit   SPACE rebirth   M mutate   S save"
        else:
            msg = self.message
        foot = self.small.render(msg, True, ACCENT)
        self.screen.blit(foot, foot.get_rect(center=(w // 2, h - 22)))

        pygame.display.flip()

    def run(self):
        running = True
        while running:
            for e in pygame.event.get():
                running = self.handle_event(e)
                if not running:
                    break
            self.draw()
            self.clock.tick(FPS)


# ----------------------------- main --------------------------------------

def main():
    engine = ButterflyEngine()
    gui = ButterflyGUI(engine)

    try:
        engine.start()
    except Exception as exc:
        pygame.quit()
        print("\nBUTTERFLYER could not open the audio device.")
        print("Audio error:", exc)
        print("\nTry checking devices with:")
        print("  python -c \"import sounddevice as sd; print(sd.query_devices())\"")
        raise SystemExit(1)

    try:
        gui.run()
    finally:
        engine.stop()
        pygame.quit()


if __name__ == "__main__":
    main()
